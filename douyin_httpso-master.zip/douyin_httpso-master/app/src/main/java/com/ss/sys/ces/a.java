package com.ss.sys.ces;

import android.content.Context;

public final class a {
    static {
        String str = "cms110";
        try {
            System.loadLibrary(str);
        } catch (UnsatisfiedLinkError e) {
            e.getMessage();
        }
    }
    public static byte[] sMetaData;

    static {
    }

    public a() {
        super();
    }

    private static final void Bill() {
    }

    public final strictfp void Francies() {
    }

    public static final void Louis() {
    }

    public static final void Zeoy() {
    }

    public static native byte[] decode(int arg0, byte[] arg1);

    public static native byte[] encode(byte[] arg0);

    public static native byte[] leviathan(int arg0, int arg1, byte[] arg2);

    public static native Object meta(int arg0, Context arg1, Object arg2);

}

